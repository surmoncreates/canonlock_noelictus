# Combat Styles
- **Nyx:** momentum-feral + horror overlay; shadow-boxing passive; escalates to Astral Convergence.
- **Haeight:** efficient blade discipline.
- **Sera:** precise ranged control.
- **Darran:** brute intimidation.
## Shadow-Boxing Passive — Tactics & Counters
- Nyx uses phase echoes to overwhelm. Counters: wide parries; flood light; distance control.
