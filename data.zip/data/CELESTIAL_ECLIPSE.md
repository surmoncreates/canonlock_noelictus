# Celestial Eclipse — Domain Overview
- Bridge beyond flesh: constellation paths; eclipse stillness.
- Techniques: Constellation Step; Orbital Flow; Event Horizon Kick; Celestial Dirge (non-combat singing seed).
- Aura: corona halo, clean arcs; star-lines instead of chaotic flicker.
- Perception: awe-forward; inevitability.
