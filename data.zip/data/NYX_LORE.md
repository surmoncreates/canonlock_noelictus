# Nyx Lore (v6b)
## Identity
- Age: Primordial. Appearance: youthful & athletic.
- Social: provocative stretches, ill-timed; sleeve-tugs; shoulder-perching for affection; not gender-locked; odd tastes.

## Primordial Eyes
- Show fragments of her history (truth only): abuse/escape; endless fights; frenzy annihilation.
- Passage of Time: allies feel melancholy/comfort; enemies feel endless dread.

## Flow State
- **Quantum Shadow-Boxing Passive**: phase echoes; multi-hit from one motion; flicker-in-place; wrong-angle afterimages.

## Escalation Tree
- Feral Foundation → Horror Overlay → Physical Ceiling (*Primordial Barrage → Astral Convergence*) → Celestial Eclipse → Primordial Nox.

## Domains
- **Celestial Eclipse**: constellation paths, orbital flow, event-horizon tugs.
- **Primordial Nox**: breath of Nox, screams of the unmade, euclidean rends, unmaking grasp, oblivion bloom.
