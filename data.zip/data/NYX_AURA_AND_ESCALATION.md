# Aura & Escalation (Quantum Shadow-Boxing Passive)
- In flow, her Primordial/quantum nature bleeds into reality: phase echoes, double-hits, flicker frames, lagging shadows.
- Tier 2: visible flicker aids Rapid Flurry. Tier 3: enables Astral Convergence. Tier 4–5: stabilizes as constellation arcs or unravels into euclidean rends.
