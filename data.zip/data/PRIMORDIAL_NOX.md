# Primordial Nox — Domain Overview
- Apex alien: angles fold; silence is weight.
- Techniques: Breath of Nox; Screams of the Unmade; Euclidean Rend; Unmaking Grasp; Oblivion Bloom; Endless Maw.
- Aura: fractures, late echoes, melancholy for allies, despair for enemies.
- Perception: terror; used as last door.
